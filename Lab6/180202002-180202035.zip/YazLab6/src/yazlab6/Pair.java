package yazlab6;

class Pair{
    public int source;
    public int destination;
 
    public Pair (int source, int destination){
        
        this.source = source;
        this.destination = destination;
    }
 
    public Pair(){}
}