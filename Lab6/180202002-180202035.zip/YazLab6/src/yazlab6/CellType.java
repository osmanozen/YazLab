package yazlab6;

public enum CellType {

    NODE_START,
    NODE_MID,
    NODE_FINISH;
}