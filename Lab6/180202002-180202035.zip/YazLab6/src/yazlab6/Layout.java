package yazlab6;

public abstract class Layout {

    public abstract void execute();

}